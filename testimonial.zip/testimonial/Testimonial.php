<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="testimonial/style.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css">
  <body>

    <div class="testimonials">
      <div class="inner">
        <h1>What users says!</h1>
        <div class="border"></div>

        <div class="row">
          <div class="col">
            <div class="testimonial">
              <img src="testimonial/download (1).jfif" alt="">
              <div class="name">Kritika singh</div>
              <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
              </div>

              <p>
                This site is very helpful for us.
              </p>
            </div>
          </div>

          <div class="col">
            <div class="testimonial">
              <img src="testimonial/boy.webp" alt="">
              <div class="name">Raj KUmar</div>
              <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="far fa-star"></i>
                <i class="far fa-star"></i>
              </div>

              <p>
                Very useful for me.
              </p>
            </div>
          </div>

          <div class="col">
            <div class="testimonial">
              <img src="testimonial/download.jfif" alt="">
              <div class="name">Punam Kumari</div>
              <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="far fa-star"></i>
              </div>

              <p>
               Safe and secure for me.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>

<div class="testimonials">
  <div class="inner">
    
      <h1>What Owners Says!</h1>
      <div class="border"></div>
    
      <div class="row">
        <div class="col">
          <div class="testimonial">
            <img src="testimonial/woman.jpg" alt="">
            <div class="name">Mrs. Kritilata</div>
            <div class="stars">
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
              <i class="far fa-star"></i>
            </div>
    
            <p>
              This site is very helpful for us.
            </p>
          </div>
        </div>
    
        <div class="col">
          <div class="testimonial">
            <img src="testimonial/man.webp" alt="">
            <div class="name">Mr. Gopal Das</div>
            <div class="stars">
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
            </div>
    
            <p>
              Very useful for me.
            </p>
          </div>
        </div>
    
        <div class="col">
          <div class="testimonial">
            <img src="testimonial/woman.webp" alt="">
            <div class="name">Mrs. Anjali Devi</div>
            <div class="stars">
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
              <i class="fas fa-star"></i>
              <i class="far fa-star"></i>
              <i class="far fa-star"></i>
            </div>
    
            <p>
               very Useful for me.
            </p>
          </div>
        </div>
      </div>
    </div>
    </div>
  </body>
</html>
